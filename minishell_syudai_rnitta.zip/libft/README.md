# libft

## Usage

Use `make` to make libft.a without bonus.

Use `make bonus` to make libft.a with bonus.
